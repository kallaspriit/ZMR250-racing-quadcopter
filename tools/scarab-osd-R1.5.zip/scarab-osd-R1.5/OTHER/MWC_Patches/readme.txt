This folder contains files and patches needed to modify multiwii source code for compatibility with new osd features.

Instructions on patching can be found in "patching.txt" guide.

Current patches:

msp_gps_time_mw_2.3.patch - this adds the gps time into multiwii 2.3 serial protocol, which allows the osd to recieve it & show it

