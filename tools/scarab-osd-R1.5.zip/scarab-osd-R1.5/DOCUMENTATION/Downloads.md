
---

Download the latest release of MW OSD here:-

**Release 1.4.1 - 15/06/2015 :**

[MW OSD R1.4.1](https://drive.google.com/uc?export=download&id=0B2MInRUrbpWxbU9PUmtzdFZXams)

---

[Go here for Beta releases of MWOSD](https://github.com/ShikOfTheRa/scarab-osd/releases)

---
---

Historic releases of MW OSD are here:-

**Release 1.3SP2 - 20/03/2015 :**

[MW OSD R1.3SP2](https://drive.google.com/uc?export=download&id=0B2MInRUrbpWxNXV3SVVYNzlmMEE)

**Release 1.3 - 02/03/2015 :**

[MW OSD R1.3](https://drive.google.com/uc?export=download&id=0B2MInRUrbpWxZXJDSmY4YkFlcFE)

**Release 1.2 - 04/10/2014 :**

[MW OSD R1.2](https://drive.google.com/uc?export=download&id=0B2MInRUrbpWxQ2tEYUxvazFBWW8)


**Release 1.1 - 15/05/2014 :**

[MW OSD R1.1](https://drive.google.com/uc?export=download&id=0B2MInRUrbpWxZFd6eGtibGIxSUU)


**Release 1 - 19/03/2014 :**

[MW OSD R1](https://drive.google.com/uc?export=download&id=0B2MInRUrbpWxdkdHQTFtTzFrRm8)


