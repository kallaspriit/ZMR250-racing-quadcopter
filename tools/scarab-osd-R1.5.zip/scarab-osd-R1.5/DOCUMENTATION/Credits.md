This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 3 of the License, or any later version. See http://www.gnu.org/licenses/

This work is based on the following open source work :-
<li> Rushduino                 <a href='http://code.google.com/p/rushduino-osd/'>http://code.google.com/p/rushduino-osd/</a>
<li> Rush OSD Development      <a href='https://code.google.com/p/rush-osd-development/'>https://code.google.com/p/rush-osd-development/</a>
<li> Minim OSD                 <a href='https://code.google.com/p/arducam-osd/wiki/minimosd'>https://code.google.com/p/arducam-osd/wiki/minimosd</a>

Its base is taken as a fork from "Rush OSD Development" <a href='https://code.google.com/p/multiwii-osd/source/detail?r=370'>R370</a>


All credit and full acknowledgement to the incredible work and hours from the many developers, contributors and testers that have helped along the way.<br>
<br>
Jean Gabriel Maurice. He started the revolution. He was the first....<br>
